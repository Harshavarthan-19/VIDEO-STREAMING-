//
//  HomeViewModel.swift
//  Netflix_Clone
//
//  Created by JAYANTA GOGOI on 6/16/20.
//  Copyright © 2020 JAYANTA GOGOI. All rights reserved.
//

import UIKit

class HomeViewModel: NSObject {
        
    
    override init() {
        print("init View Model")
    }
    
    
    
    
}
