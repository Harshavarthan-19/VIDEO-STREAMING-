//
//  LandingFeature.swift
//  Netflix_Clone
//
//  Created by JAYANTA GOGOI on 5/25/20.
//  Copyright © 2020 JAYANTA GOGOI. All rights reserved.
//

import UIKit

struct LandingFeature {
    var headline: String
    var description: String
    var imgIcon: UIImage?
}
